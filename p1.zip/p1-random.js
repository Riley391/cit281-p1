/* 
    CIT 281 Project 1
    Payton Lommers
*/

function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

// declares an array containing every letter choice and an empty string that the random letters will be added to
let letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
let finalString = "";

// this loop adds one random letter from letters to finalString until i reaches a random number between 5 and 15
for (let i = 0; i < getRandomNumber(5, 16); i++) {
    finalString += letters[getRandomNumber(0, 26)];
}

console.log(finalString);